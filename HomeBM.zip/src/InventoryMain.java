import java.util.List;
import java.util.Scanner;

import org.apache.ibatis.session.SqlSession;

import com.config.MySqlSessionFactory;
import com.dao.InventoryDAO;
import com.dto.InventoryDTO;
import com.service.InventoryService;
import com.service.InventoryServiceImpl;

public class InventoryMain {

	public static void main(String[] args) {
		InventoryService service = new InventoryServiceImpl();
		service.setDao(new InventoryDAO());
		Scanner scan = new Scanner(System.in);
		
		while(true) {
			System.out.println("1. 상품 조회");
			System.out.println("--------------------");
			String num = scan.next();
	
			if("1".equals(num)) {
				List<InventoryDTO> list = service.findAllInventory();
				for (InventoryDTO e : list) {
					System.out.println(e);
				}
			}
		}
	}

}
