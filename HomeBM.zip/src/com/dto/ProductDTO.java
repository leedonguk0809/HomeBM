package com.dto;

public class ProductDTO {
	private String ProductID;
	private String ProductName;
	private int Price;
	private String Category;
	private String Descript;
	
	public ProductDTO() {
	}
	public ProductDTO(String productID, String productName, int price, String category, String descript) {
		this.ProductID = productID;
		this.ProductName = productName;
		this.Price = price;
		this.Category = category;
		this.Descript = descript;
	}
	public String getProductID() {
		return ProductID;
	}
	public void setProductID(String productID) {
		this.ProductID = productID;
	}
	public String getProductName() {
		return ProductName;
	}
	public void setProductName(String productName) {
		this.ProductName = productName;
	}
	public int getPrice() {
		return Price;
	}
	public void setPrice(int price) {
		this.Price = price;
	}
	public String getCategory() {
		return Category;
	}
	public void setCategory(String category) {
		this.Category = category;
	}
	public String getDescript() {
		return Descript;
	}
	public void setDescript(String descript) {
		this.Descript = descript;
	}
	
	@Override
	public String toString() {
		return "ProductDTO [ProductID="+ ProductID + ", ProductName="+ ProductName +", Price="+ Price +", Category= "+ Category +", Descript= "+ Descript +"]";
	}
	
}
