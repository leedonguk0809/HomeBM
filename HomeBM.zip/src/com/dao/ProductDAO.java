package com.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dto.ProductDTO;

public class ProductDAO {
	//select
	public List<ProductDTO> findAll(SqlSession session){
		List<ProductDTO> list = session.selectList("com.config.ProductMapper.findAll");
		return list;
	}
	
	//insert
	public int save(SqlSession session, ProductDTO dto) {
		return session.insert("com.config.ProductMapper.save", dto);
	}
	
	//delete
	public int removeByProduct(SqlSession session, int ProductID) {
		return session.delete("com.config.ProductMapper.removeByProduct", ProductID);
	}

}
