package com.dao;

public class TDetailDAO {

}
