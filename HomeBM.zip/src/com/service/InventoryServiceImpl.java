package com.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.config.MySqlSessionFactory;
import com.dao.InventoryDAO;
import com.dto.InventoryDTO;

public class InventoryServiceImpl implements InventoryService{
		private InventoryDAO dao;
		public void setDao(InventoryDAO dao) {
			this.dao = dao;
		}
		
		@Override
		public List<InventoryDTO> findAllInventory(){
			List<InventoryDTO> list = null;
			SqlSession session = null;
			try {
				session = MySqlSessionFactory.getSession();
				list = dao.findAllInventory(session);
			}finally {
				session.close();
			}
			return list;
		}

}
