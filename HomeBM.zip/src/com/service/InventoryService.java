package com.service;

import java.util.List;

import com.dao.InventoryDAO;
import com.dto.InventoryDTO;

public interface InventoryService {
	public void setDao(InventoryDAO dao);
	public List<InventoryDTO> findAllInventory();

}
